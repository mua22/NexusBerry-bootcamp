const multer = require("multer");
var storage = multer.diskStorage({
  destination: function(req, file, callback) {
    callback(null, "./public/uploads");
  },
  filename: function(req, file, callback) {
    callback(null, file.fieldname + "-" + Date.now() + "-" + file.originalname);
  }
});
var uploadUserPhoto = multer({ storage: storage }).array("images", 5);
module.exports.uploadImages = uploadUserPhoto;
