module.exports = function(req, res, next) {
  try {
    if (req.cookies.user_sid && !req.session.user) res.clearCookie("user_sid");
  } catch (e) {
    console.log(e);
  }

  next();
};
