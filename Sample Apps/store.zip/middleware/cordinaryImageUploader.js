const multer = require("multer");
const cloudinary = require("cloudinary");
const cloudinaryStorage = require("multer-storage-cloudinary");
const config = require("config");
cloudinary.config({
  cloud_name: config.get("CLOUDINARY_CLOUD_NAME"),
  api_key: config.get("CLOUDINARY_API_KEY"),
  api_secret: config.get("CLOUDINARY_API_SECRET")
});
const storage = cloudinaryStorage({
  cloudinary: cloudinary,
  folder: "asianbrandedclothes",
  allowedFormats: ["jpg", "png"],
  transformation: [{ width: 300, crop: "scale" }]
});
const parser = multer({ storage: storage });
module.exports.parser = parser;
module.exports.cloudinary = cloudinary;
