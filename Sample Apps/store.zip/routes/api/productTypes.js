const express = require("express");
const router = express.Router();
const UrlSafeString = require("url-safe-string");
const tagGenerator = new UrlSafeString();
const { ProductType } = require("../../models/ProductType");

router.get("/", async (req, res) => {
  const productTypes = await ProductType.find();
  res.send(productTypes);
});

router.post("/", async (req, res) => {
  console.log("Request Received at server");

  let data = req.body;
  data.permalink = tagGenerator.generate(data.name);
  var _id = data._id;
  console.log(data);
  delete data._id;
  let productType = null;
  if (_id == 0 || !_id) {
    productType = new ProductType(data);
    await productType.save().catch(e => console.log("Error occured" + e));
    return res.send(productType);
  } else {
    productType = await ProductType.findByIdAndUpdate(_id, data);
    if (!productType)
      return res
        .status(404)
        .send("The ProductType with the given ID was not found.");
    else return res.send(productType);
  }
});

router.delete("/:id", async (req, res) => {
  const productType = await ProductType.findByIdAndRemove(req.params.id);
  if (!productType)
    return res
      .status(404)
      .send("The ProductType with the given ID was not found.");
  res.send(productType);
});

router.get("/:id", async (req, res) => {
  const productType = await ProductType.findById(req.params.id);
  if (!productType)
    return res
      .status(404)
      .send("The ProductType with the given ID was not found.");
  res.send(productType);
});

router.put("/:id", async (req, res) => {
  let data = req.body;
  data.permalink = tagGenerator.generate(data.name);
  const updatedProductType = await ProductType.findByIdAndUpdate(
    req.params.id,
    data
  );
  if (!updatedProductType)
    return res
      .status(404)
      .send("The ProductType with the given ID was not found.");
  res.send(updatedProductType);
});

module.exports = router;
