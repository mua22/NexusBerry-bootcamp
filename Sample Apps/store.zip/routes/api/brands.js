const express = require("express");
const router = express.Router();
const UrlSafeString = require("url-safe-string");
const tagGenerator = new UrlSafeString();
const { Brand } = require("../../models/Brand");

router.get("/", async (req, res) => {
  const brands = await Brand.find();
  res.send(brands);
});

router.post("/", async (req, res) => {
  console.log("Request Received at server");

  let data = req.body;
  data.permalink = tagGenerator.generate(data.name);
  var _id = data._id;
  console.log(data);
  delete data._id;
  let brand = null;
  if (_id == 0) {
    brand = new Brand(data);
    await brand.save().catch(e => console.log("Error occured" + e));
    return res.send(brand);
  } else {
    brand = await Brand.findByIdAndUpdate(_id, data);
    if (!brand)
      return res.status(404).send("The Brand with the given ID was not found.");
    else return res.send(brand);
  }
});

router.delete("/:id", async (req, res) => {
  const brand = await Brand.findByIdAndRemove(req.params.id);
  if (!brand)
    return res.status(404).send("The Brand with the given ID was not found.");
  res.send(brand);
});

router.get("/:id", async (req, res) => {
  const brand = await Brand.findById(req.params.id);
  if (!brand)
    return res.status(404).send("The Brand with the given ID was not found.");
  res.send(brand);
});

router.put("/:id", async (req, res) => {
  let data = req.body;
  data.permalink = tagGenerator.generate(data.name);
  const updatedBrand = await Brand.findByIdAndUpdate(req.params.id, data);
  if (!updatedBrand)
    return res.status(404).send("The Brand with the given ID was not found.");
  res.send(updatedBrand);
});

module.exports = router;
