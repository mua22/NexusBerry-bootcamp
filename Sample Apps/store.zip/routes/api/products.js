const express = require("express");
const sharp = require("sharp");
const router = express.Router();
const fs = require("fs");
const { uploadImages } = require("../../utils");
const { Product } = require("../../models/Product");
const { Image } = require("../../models/Image");
const {
  parser,
  cloudinary
} = require("../../middleware/cordinaryImageUploader");
//delete Image
router.get("/image/:id/:index", async (req, res) => {
  const product = await Product.findById(req.params.id);
  const image = product.images[req.params.index];
  product.images.splice(req.params.index, 1);
  cloudinary.v2.api.delete_resources([image.public_id], function(
    error,
    result
  ) {
    console.log(result, error);
  });
  const img = await Image.findByIdAndDelete(image._id);
  //fs.unlinkSync("./public/uploads/" + imageName);
  await product.save();
  res.send(product);
});

router.get("/", async (req, res) => {
  const products = await Product.find();
  res.send(products);
});

router.post("/upload/:id", parser.array("image", 10), async (req, res) => {
  const product = await Product.findById(req.params.id);
  //console.log("uploaded to cloudinary");
  //console.log(req.file);
  for (var i = 0; i < req.files.length; i++) {
    var image = new Image(req.files[i]);
    await image.save();
    product.images.push(image);
  }
  await product.save();
  res.send(product);
  // });
});

router.post("/", async (req, res) => {
  console.log("Product Request Received at server");
  let data = req.body;
  console.log(data);
  var _id = data._id;
  delete data._id;
  let product = null;
  if (_id == 0) {
    console.log("saving new product");
    product = new Product(data);
    await product.save().catch(e => console.log("Error occured" + e));
    return res.send(product);
  } else {
    product = await Product.findByIdAndUpdate(_id, data);
    if (!product)
      return res
        .status(404)
        .send("The Product with the given ID was not found.");
    else return res.send(product);
  }
});

router.delete("/:id", async (req, res) => {
  const product = await Product.findByIdAndRemove(req.params.id);
  if (!product)
    return res.status(404).send("The Product with the given ID was not found.");
  res.send(product);
});

router.get("/:id", async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product)
    return res.status(404).send("The Product with the given ID was not found.");
  res.send(product);
});

router.put("/:id", async (req, res) => {
  let data = req.body;
  const updatedProduct = await Product.findByIdAndUpdate(req.params.id, data);
  if (!updatedProduct)
    return res.status(404).send("The Product with the given ID was not found.");
  res.send(updatedProduct);
});

module.exports = router;
