const express = require("express");
const router = express.Router();

const { Expense } = require("../../models/Expense");

router.get("/", async (req, res) => {
  const expenses = await Expense.find();
  res.send(expenses);
});

router.post("/", async (req, res) => {
  console.log("Request Received at server");

  let data = req.body;
  var _id = data._id;
  console.log(data);
  delete data._id;
  let expense = null;
  if (_id == 0) {
    expense = new Expense(data);
    await expense.save().catch(e => console.log("Error occured" + e));
    return res.send(expense);
  } else {
    expense = await Expense.findByIdAndUpdate(_id, data);
    if (!expense)
      return res
        .status(404)
        .send("The Expense with the given ID was not found.");
    else return res.send(expense);
  }
});

router.delete("/:id", async (req, res) => {
  const expense = await Expense.findByIdAndRemove(req.params.id);
  if (!expense)
    return res.status(404).send("The Expense with the given ID was not found.");
  res.send(expense);
});

router.get("/:id", async (req, res) => {
  const expense = await Expense.findById(req.params.id);
  if (!expense)
    return res.status(404).send("The Expense with the given ID was not found.");
  res.send(expense);
});

router.put("/:id", async (req, res) => {
  let data = req.body;
  const updatedExpense = await Expense.findByIdAndUpdate(req.params.id, data);
  if (!updatedExpense)
    return res.status(404).send("The Expense with the given ID was not found.");
  res.send(updatedExpense);
});

module.exports = router;
