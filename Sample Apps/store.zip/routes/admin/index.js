var express = require("express");
var router = express.Router();
const multer = require("multer");
const bcrypt = require("bcrypt");
const sessionAuth = require("../../middleware/sessionAuth");
const { Brand } = require("../../models/Brand");
const { ProductType } = require("../../models/ProductType");
const { User } = require("../../models/User");
/* GET Login page. */
router.get("/login", function(req, res, next) {
  res.render("admin/pages/login");
});
router.post("/auth", async function(req, res, next) {
  console.log(req.body);
  let user = await User.findOne({ email: req.body.email });
  if (!user) return res.redirect("/admin/login");
  const validPassword = await bcrypt.compare(req.body.password, user.password);
  if (!validPassword) return res.redirect("/admin/login");
  //console.log(user);
  req.session.user = { name: user.name, email: user.email };
  return res.redirect("/admin");
});
/* GET home page. */
router.get("/", sessionAuth, function(req, res, next) {
  res.redirect("/admin/products");
});
router.get("/expenses", sessionAuth, function(req, res, next) {
  res.render("admin/expenses/index", { title: "Expenses" });
});
router.get("/products", sessionAuth, async function(req, res, next) {
  console.log(Brand);
  const brands = await Brand.find();
  const types = await ProductType.find();

  res.render("admin/products/index", { title: "Brands", brands, types });
});
router.get("/brands", sessionAuth, function(req, res, next) {
  res.render("admin/brands/index", { title: "Brand" });
});
router.get("/types", sessionAuth, function(req, res, next) {
  res.render("admin/types/index", { title: "Type" });
});
var storage = multer.diskStorage({
  destination: function(req, file, callback) {
    callback(null, "./public/uploads");
  },
  filename: function(req, file, callback) {
    callback(null, file.fieldname + "-" + Date.now() + "-" + file.originalname);
  }
});
var upload = multer({ storage: storage }).array("userPhoto", 2);
router.post("/photo", sessionAuth, function(req, res) {
  upload(req, res, function(err) {
    //console.log(req.body);
    console.log(req.files);
    if (err) {
      return res.end("Error uploading file." + err);
    }
    res.end("File is uploaded");
  });
});

module.exports = router;
