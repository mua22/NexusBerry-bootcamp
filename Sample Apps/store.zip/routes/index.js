var express = require("express");
var router = express.Router();
var { Brand } = require("../models/Brand");
var { Product } = require("../models/Product");
var { ProductType } = require("../models/ProductType");
/* GET home page. */
const prepareFrontEndData = async function() {
  const brands = await Brand.find();
  const types = await ProductType.find();
  return { brands, types };
};
router.get("/", async function(req, res, next) {
  var data = await prepareFrontEndData();
  // console.log(data);
  const products = await Product.find();
  // console.log(products);
  res.render("shop/index", {
    title: "Asian Branded Clothes",
    data,
    products
  });
});
/* GET home page. */
router.get("/brands/:name", async function(req, res, next) {
  var data = await prepareFrontEndData();
  const products = await Product.find({ brand: req.params.name });
  // console.log(products);
  res.render("shop/index", {
    title: "Asian Branded Clothes",
    data,
    products
  });
});
/* GET home page. */
router.get("/products/category/:name", async function(req, res, next) {
  var data = await prepareFrontEndData();
  const products = await Product.find({ type: req.params.name });
  // console.log(products);
  res.render("shop/index", {
    title: "Asian Branded Clothes",
    data,
    products
  });
});
router.get("/product/:id", async function(req, res, next) {
  var data = await prepareFrontEndData();
  const product = await Product.findById(req.params.id);
  console.log(data);
  var foundType = data.types.find(function(t) {
    return t.permalink == product.type;
  });
  var foundBrand = data.brands.find(function(t) {
    return t.permalink == product.brand;
  });
  if (foundType) product.type = foundType.name;
  if (foundBrand) product.brand = foundBrand.name;
  //console.log(found);
  // console.log(product);
  res.render("shop/details", {
    title: "Asian Branded Clothes",
    data,
    product
  });
});

module.exports = router;
