const sharp = require("sharp");
const path = require("path");
const pathObj = path.parse(__dirname);
console.log(pathObj);

sharp("test.jpg")
  .resize(300)
  .toBuffer()
  .then(data => {
    console.log(data);
  })
  .catch(err => {
    console.log(err);
  });
