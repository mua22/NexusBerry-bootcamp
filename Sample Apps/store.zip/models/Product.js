const Joi = require("joi");
const mongoose = require("mongoose");
const { imageSchema } = require("./Image");
const productSchema = new mongoose.Schema({
  code: String,
  name: String,
  size: String,
  color: String,
  brand: String,
  price: String,
  sell_price: String,
  old_price: String,
  type: String,
  purchase_price: String,
  description: String,
  images: [imageSchema],
  published: String,
  sold: String
});
const Product = mongoose.model("Product", productSchema);
function validateProduct(product) {
  const schema = {
    type: Joi.String()
      .min(0)
      .max(20)
  };
}

exports.Product = Product;
exports.validate = validateProduct;
