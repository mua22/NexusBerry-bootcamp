const Joi = require("joi");
const mongoose = require("mongoose");

const imageSchema = new mongoose.Schema({
  fieldname: String,
  origionalname: String,
  encoding: String,
  mimetype: String,
  public_id: String,
  signature: String,
  width: String,
  height: String,
  format: String,
  resource_type: String,
  created_at: String,
  tags: [String],
  bytes: String,
  type: String,
  url: String,
  secure_url: String,
  request_ip: String,
  origional_filename: String
});
const Image = mongoose.model("Image", imageSchema);
function validateImage(image) {
  const schema = {
    name: Joi.String()
      .min(0)
      .max(20),
    permalink: Joi.String()
      .min(0)
      .max(20),
    description: Joi.String()
      .min(0)
      .max(20)
  };
  return Joi.validate(image, schema);
}

exports.imageSchema = imageSchema;
exports.Image = Image;
exports.validate = validateImage;
