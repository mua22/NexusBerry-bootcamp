const Joi = require("joi");
const mongoose = require("mongoose");

const expenseSchema = new mongoose.Schema({
  date: Date,
  type: String,
  description: String,
  amount: Number
});
const Expense = mongoose.model("Expense", expenseSchema);
function validateExpense(expense) {
  const schema = {
    date: Joi.date(),
    type: Joi.String()
      .min(0)
      .max(20),
    description: Joi.String()
      .min(0)
      .max(1000),
    amount: Joi.number()
  };
}

exports.Expense = Expense;
exports.validate = validateExpense;
