const Joi = require("joi");
const mongoose = require("mongoose");

const productTypeSchema = new mongoose.Schema({
  name: String,
  permalink: String,
  description: String
});

const ProductType = mongoose.model("ProductType", productTypeSchema);
function validateProductType(productType) {
  const schema = {
    name: Joi.String()
      .min(0)
      .max(20),
    url: Joi.String()
      .min(0)
      .max(20),
    description: Joi.String()
      .min(0)
      .max(20)
  };
  return Joi.validate(productType, schema);
}

exports.ProductType = ProductType;
exports.validate = validateProductType;
