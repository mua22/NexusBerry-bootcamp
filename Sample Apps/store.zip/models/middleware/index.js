const UrlSafeString = require("url-safe-string");
module.exports.generatePermalinkFromName = function(next) {
  const tagGenerator = new UrlSafeString();
  this.permalink = tagGenerator.generate(this.name);
  next();
};
