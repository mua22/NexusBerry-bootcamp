const Joi = require("joi");
const mongoose = require("mongoose");

const brandSchema = new mongoose.Schema({
  name: String,
  permalink: String,
  description: String
});
const Brand = mongoose.model("Brand", brandSchema);
function validateBrand(brand) {
  const schema = {
    name: Joi.String()
      .min(0)
      .max(20),
    permalink: Joi.String()
      .min(0)
      .max(20),
    description: Joi.String()
      .min(0)
      .max(20)
  };
  return Joi.validate(brand, schema);
}

exports.Brand = Brand;
exports.validate = validateBrand;
