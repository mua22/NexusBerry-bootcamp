$(function() {
  loadExpenses();
  $("#expenseTable").on("click", ".delete", handleExpenseDelete);
  $("#expenseTable").on("click", ".edit", handleExpenseEdit);
  $("#addNew").click(function(e) {
    e.preventDefault();
    $("#expenseForm").trigger("reset");
    $("#expenseModal").modal("show");
    $("#id").val(0);
  });
  //   $("#addNew").trigger("click");
});

$("#expenseSaveButton").click(function() {
  console.log("Sending ajax");
  $.ajax({
    url: "/api/expenses",
    method: "POST",
    data: $("#expenseForm").serialize(),
    success: function(data) {
      console.log("Saved:");
      console.log(data);
      loadExpenses();
      $("#expenseModal").modal("hide");
    },
    error: function(e) {
      console.log(e);
    }
  });
});

function loadExpenses() {
  console.log("inside load expenses");
  if ($("#expenseTable")) {
    console.log("sending get");
    $.ajax({
      url: "/api/expenses",
      method: "GET",
      success: function(data, status) {
        $("#expenseTable tbody").html("");
        data.forEach(expense => {
          $("#expenseTable tbody").append(`<tr>
            <td>${expense.date}</td>
            <td>${expense.type}</td>
            <td>${expense.amount}</td>
            <td>${expense.description}</td>
            <td>
            <a href="#" class="btn btn-warning btn-xs edit" data-id="${expense._id}"><i class="fas fa-edit" title="Edit" data-original-title="Edit"></i></a>
            <a href="#" class="btn btn-danger btn-xs delete" data-id="${expense._id}"><i class="fa fa-trash" title="Delete" data-original-title="Delete"></i></a>
            </td>
            </tr>`);
        });
      }
    });
  }
}

function handleExpenseEdit() {
  var id = $(this).attr("data-id");
  $.get("/api/expenses/" + id, function(data, status) {
    $("#id").val(data._id);
    $("#date").val(data.date);
    $("#type").val(data.type);
    $("#amount").val(data.amount);
    $("#description").val(data.description);
    $("#expenseModal").modal("show");
  });
}
function handleExpenseDelete(e) {
  e.preventDefault();
  var id = $(this).attr("data-id");
  $.ajax({
    url: "/api/expenses/" + id,
    method: "DELETE",
    success: function(data, status) {
      loadExpenses();
    }
  });
}
// $("#expenseSaveButton").trigger("click");
