$(function() {
  $(".datepicker").daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    maxYear: parseInt(moment().format("YYYY"), 10),
    locale: {
      format: "YYYY-MM-DD"
    }
  });
});
