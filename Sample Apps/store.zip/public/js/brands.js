$(function() {
  loadData();
  $("#brandsTable").on("click", ".delete", handleDelete);
  $("#brandsTable").on("click", ".edit", handleEdit);
  $("#addNew").click(function(e) {
    e.preventDefault();
    $("#brandsForm").trigger("reset");
    $("#brandsModal").modal("show");
    $("#id").val(0);
  });
  //   $("#addNew").trigger("click");
});

$("#expenseSaveButton").click(function() {
  console.log("Sending ajax");
  $.ajax({
    url: "/api/brands",
    method: "POST",
    data: $("#brandsForm").serialize(),
    success: function(data) {
      console.log("Saved:");
      console.log(data);
      loadData();
      $("#brandsModal").modal("hide");
    },
    error: function(e) {
      console.log(e);
    }
  });
});

function loadData() {
  console.log("inside load expenses");
  if ($("#brandsTable")) {
    console.log("sending get");
    $.ajax({
      url: "/api/brands",
      method: "GET",
      success: function(data, status) {
        $("#brandsTable tbody").html("");
        data.forEach(expense => {
          $("#brandsTable tbody").append(`<tr>
            <td>${expense.name}</td>
            
            <td>
            <a href="#" class="btn btn-warning btn-xs edit" data-id="${expense._id}"><i class="fas fa-edit" title="Edit" data-original-title="Edit"></i></a>
            <a href="#" class="btn btn-danger btn-xs delete" data-id="${expense._id}"><i class="fa fa-trash" title="Delete" data-original-title="Delete"></i></a>
            </td>
            </tr>`);
        });
      }
    });
  }
}

function handleEdit() {
  var id = $(this).attr("data-id");
  $.get("/api/brands/" + id, function(data, status) {
    $("#id").val(data._id);
    $("#name").val(data.name);

    $("#brandsModal").modal("show");
  });
}
function handleDelete(e) {
  e.preventDefault();
  var id = $(this).attr("data-id");
  $.ajax({
    url: "/api/brands/" + id,
    method: "DELETE",
    success: function(data, status) {
      loadData();
    }
  });
}
// $("#expenseSaveButton").trigger("click");
