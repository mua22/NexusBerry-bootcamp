$(function() {
  loadData();
  $("#productsTable").on("click", ".delete", handleDelete);
  $("#productsTable").on("click", ".edit", handleEdit);
  $("#productsTable").on("click", ".images", manageImages);
  $("#images").on("click", ".deleteImage", handleDeleteImage);
  $("#addNew").click(function(e) {
    e.preventDefault();
    $("#productsForm").trigger("reset");
    $("#productsModal").modal("show");
    $("#id").val(0);
  });
  // $("#addNew").trigger("click");
  $("#productPhoto").change(function(e) {
    $("#selectedFiles").empty();
    for (var i = 0; i < e.target.files.length; i++) {
      $("#selectedFiles").append(e.target.files[i].name + ", ");
    }
  });
  function handleDeleteImage(e) {
    e.preventDefault();
    var id = $(this).attr("data-id");
    var name = $(this).attr("data-name");
    var index = $(this).attr("data-index");
    $.get(`/api/products/image/${id}/${index}`, function(data, status) {
      updateImages(data.images, id);
    });
  }
  $("#uploadForm").submit(function(e) {
    e.preventDefault();
    var id = $(this).attr("data-id");
    $("#status")
      .empty()
      .text("Uploading ...");
    $(this).ajaxSubmit({
      error: function(xhr) {
        $("#status")
          .empty()
          .text("Something Went Wrong");
        console.log("error" + xhr.status);
      },
      success: function(response) {
        console.log(response);
        updateImages(response.images, id);
        $("#status")
          .empty()
          .text("Images Uploaded");
      }
    });
  });
});
function manageImages() {
  var id = $(this).attr("data-id");
  $("#images").html("Loading...");
  $("#uploadForm").attr("action", "/api/products/upload/" + id);
  $("#uploadForm").attr("data-id", id);
  $("#imagesModal").modal("show");

  $.get("/api/products/" + id, function(data, status) {
    console.log("Received: ");
    console.log(data);
    const images = data.images;
    updateImages(images, id);
  });
}
$("#expenseSaveButton").click(function() {
  console.log("Sending ajax");
  $.ajax({
    url: "/api/products",
    method: "POST",
    data: $("#productsForm").serialize(),
    success: function(data) {
      console.log("Saved:");
      console.log(data);
      loadData();
      $("#productsModal").modal("hide");
    },
    error: function(e) {
      console.log(e);
    }
  });
});

function updateImages(images, id) {
  if (typeof images === "undefined") return;
  $("#images").empty();
  for (var i = 0; i < images.length; i++) {
    var image = images[i];
    $("#images").append(`<div class="col-sm-2">      
        <img src="${image.secure_url}" class="img-fluid mb-2" alt="product image"/>
        <a class="btn btn-danger btn-xs deleteImage" data-id="${id}" data-name="${image}" data-index="${i}"><i class="fa fa-trash" title="Delete" data-original-title="Delete"></i>Delete Image</a>
    </div>`);
  }
}

function loadData() {
  console.log("inside load expenses");
  if ($("#productsTable")) {
    console.log("sending get");
    $.ajax({
      url: "/api/products",
      method: "GET",
      success: function(data, status) {
        $("#productsTable tbody").html("");
        data.forEach(expense => {
          $("#productsTable tbody").append(`<tr>
            <td><a class="btn btn-info btn-xs images"  data-id="${expense._id}"><i class="fas fa-image"></i> Manage<a/></td>
            <td>${expense.code}</td>
            <td>${expense.name}</td>
            <td>${expense.size}</td>
            <td>${expense.color}</td>
            <td>${expense.type}</td>
            <td>${expense.brand}</td>
            <td>${expense.price}</td>
            <td>${expense.sell_price}</td>
            <td>${expense.purchase_price}</td>
            <td>${expense.description}</td>            
            <td>
            <a href="#" class="btn btn-warning btn-xs edit" data-id="${expense._id}"><i class="fas fa-edit" title="Edit" data-original-title="Edit"></i></a>
            <a href="#" class="btn btn-danger btn-xs delete" data-id="${expense._id}"><i class="fa fa-trash" title="Delete" data-original-title="Delete"></i></a>
            </td>
            </tr>`);
          // $(".images:first").trigger("click");
        });
      }
    });
  }
}

function handleEdit() {
  var id = $(this).attr("data-id");
  $.get("/api/products/" + id, function(data, status) {
    $("#id").val(data._id);
    $("#name").val(data.name);
    $("#code").val(data.code);
    $("#published").val(data.published);
    $("#sold").val(data.sold);
    $("#size").val(data.size);
    $("#color").val(data.color);
    $("#brand").val(data.brand);
    $("#type").val(data.type);
    $("#price").val(data.price);
    $("#purchase_price").val(data.purchase_price);
    $("#old_price").val(data.old_price);
    $("#sell_price").val(data.sell_price);
    $("#description").val(data.description);

    $("#productsModal").modal("show");
  });
}
function handleDelete(e) {
  e.preventDefault();
  var id = $(this).attr("data-id");
  $.ajax({
    url: "/api/products/" + id,
    method: "DELETE",
    success: function(data, status) {
      loadData();
    }
  });
}
// $("#expenseSaveButton").trigger("click");
